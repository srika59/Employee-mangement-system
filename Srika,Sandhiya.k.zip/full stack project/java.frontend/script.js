
const STORAGE_KEY = "peopleflow_employees";

function getEmployees() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
  } catch {
    return [];
  }
}

function saveEmployees(employees) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(employees));
}

function money(value) {
  return "₹" + Number(value).toLocaleString("en-IN");
}

// DASHBOARD
function loadDashboard() {
  const employees = getEmployees();

  const total = document.getElementById("totalEmployees");
  const active = document.getElementById("activeEmployees");
  const departments = document.getElementById("totalDepartments");

  if (total) total.textContent = employees.length;

  if (active) {
    active.textContent =
      employees.filter(e => e.status === "Active").length;
  }

  if (departments) {
    departments.textContent =
      new Set(employees.map(e => e.department)).size;
  }
}

// ADD AND EDIT EMPLOYEE
const form = document.getElementById("employeeForm");

if (form) {
  const editId = document.getElementById("editId");

  // Load employee details when editing from the employee list
  const params = new URLSearchParams(window.location.search);
  const requestedId = params.get("edit");

  if (requestedId) {
    const employee = getEmployees().find(
      e => String(e.id) === requestedId
    );

    if (employee) {
      editId.value = employee.id;
      document.getElementById("firstName").value = employee.firstName;
      document.getElementById("lastName").value = employee.lastName;
      document.getElementById("email").value = employee.email;
      document.getElementById("department").value = employee.department;
      document.getElementById("salary").value = employee.salary;
      document.getElementById("status").value = employee.status;

      document.getElementById("formHeading").textContent = "Edit Employee";
      document.getElementById("saveButton").textContent = "Update Employee";
    }
  }

  form.addEventListener("submit", function (event) {
    event.preventDefault();

    const employees = getEmployees();
    const id = editId.value;

    const employee = {
      id: id ? Number(id) : Date.now(),
      firstName: document.getElementById("firstName").value.trim(),
      lastName: document.getElementById("lastName").value.trim(),
      email: document.getElementById("email").value.trim(),
      department: document.getElementById("department").value,
      salary: Number(document.getElementById("salary").value),
      status: document.getElementById("status").value
    };

    const duplicate = employees.some(e =>
      e.email.toLowerCase() === employee.email.toLowerCase() &&
      e.id !== employee.id
    );

    if (duplicate) {
      alert("This email already exists!");
      return;
    }

    const updated = id
      ? employees.map(e => e.id === employee.id ? employee : e)
      : [...employees, employee];

    saveEmployees(updated);
    alert(id ? "Employee updated successfully!" : "Employee added successfully!");
    window.location.href = "employees.html";
  });
}

// EMPLOYEE LIST
function displayEmployees() {
  const list = document.getElementById("employeeList");
  if (!list) return;

  const search = document.getElementById("search").value.toLowerCase();

  const employees = getEmployees().filter(e =>
    `${e.firstName} ${e.lastName} ${e.email} ${e.department}`
      .toLowerCase().includes(search)
  );

  list.replaceChildren();

  document.getElementById("emptyMessage").style.display =
    employees.length ? "none" : "block";

  employees.forEach(e => {
    const row = document.createElement("tr");

    const values = [
      `${e.firstName} ${e.lastName}`,
      e.email,
      e.department,
      money(e.salary)
    ];

    values.forEach(value => {
      const cell = document.createElement("td");
      cell.textContent = value;
      row.appendChild(cell);
    });

    const statusCell = document.createElement("td");
    const badge = document.createElement("span");
    badge.className = "status " + e.status.toLowerCase().replace(" ", "-");
    badge.textContent = e.status;
    statusCell.appendChild(badge);
    row.appendChild(statusCell);

    const actions = document.createElement("td");

    const edit = document.createElement("button");
    edit.className = "action-btn";
    edit.textContent = "Edit";
    edit.addEventListener("click", () => {
      window.location.href = `add-employee.html?edit=${e.id}`;
    });

    const del = document.createElement("button");
    del.className = "action-btn delete-btn";
    del.textContent = "Delete";
    del.addEventListener("click", () => {
      if (confirm("Delete this employee?")) {
        saveEmployees(getEmployees().filter(item => item.id !== e.id));
        displayEmployees();
      }
    });

    actions.append(edit, del);
    row.appendChild(actions);
    list.appendChild(row);
  });
}

const searchInput = document.getElementById("search");

if (searchInput) {
  searchInput.addEventListener("input", displayEmployees);
}

loadDashboard();
displayEmployees();
